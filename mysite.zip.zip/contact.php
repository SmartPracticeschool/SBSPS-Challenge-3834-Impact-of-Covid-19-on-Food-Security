<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
	<link rel="stylesheet" type="text/css" href="cssibm/contact.css">
</head>
<body>
<div class="welcome-text">
<h1><center>Contact me@</center></h1>
<h2><center>dhayakrishnan369@gmail.com</center></h2>
</div>
</body>
</html>