<?php
session_start();

include("includes/connection.php");

	if(isset($_POST['sign_in'])){

		$email = htmlentities(mysqli_real_escape_string($con, $_POST['email']));
		$pass = htmlentities(mysqli_real_escape_string($con, $_POST['pass']));

		$select_user = "select * from userdetails where user_email='$email' AND user_pass='$pass'";

		$query = mysqli_query($con, $select_user);
		$check_user = mysqli_num_rows($query);

		if($check_user == 1){
			$_SESSION['user_email']=$email;

			$update_msg = mysqli_query($con, "UPDATE userdetails SET log_in='Online' WHERE user_email='$email'");


			$user = $_SESSION['user_email'];

			$get_user = "select * from userdetails where user_email='$user'";
			$run_user = mysqli_query($con, $get_user);
			$row = mysqli_fetch_array($run_user);

			echo "<script>window.open('home.php?user_email=$user_email', '_self')</script>";
		}
		else{
			echo"

			<div class='alert alert-danger'>
				<strong>Invalid Email or Password.</strong>
			</div>

				";
		}
	}




?>