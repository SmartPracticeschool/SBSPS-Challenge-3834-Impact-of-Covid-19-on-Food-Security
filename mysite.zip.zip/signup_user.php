<?php
include("includes/connection.php");

	if(isset($_POST['sign_up'])){
		$email = htmlentities(mysqli_real_escape_string($con, $_POST['user_email']));
		$pass = htmlentities(mysqli_real_escape_string($con, $_POST['user_pass']));
		$country = htmlentities(mysqli_real_escape_string($con, $_POST['user_country']));
		$others = htmlentities(mysqli_real_escape_string($con, $_POST['user_others']));
		$mobilenumber = htmlentities(mysqli_real_escape_string($con, $_POST['user_mobilenumber']));
		$gender = htmlentities(mysqli_real_escape_string($con, $_POST['user_gender']));
		$forgotten_answer = htmlentities(mysqli_real_escape_string($con, $_POST['forgotten_answer']));
		$rand = rand(1, 2);

		$check_email = "select * from userdetails where user_email='$email'";
		$run_email = mysqli_query($con, $check_email);

		$check = mysqli_num_rows($run_email);

		if($check==1){
			echo"<script>alert('Email already exist, please try again')</script>";
			echo"<script>window.open('signup.php', '_self')</script>";
			exit();

		}
		if(strlen($pass)<8){
			echo"<script>alert('Password should be minimum 8 characters!')</script>";
			exit();
		}

	    $insert = "insert into userdetails (user_email, user_pass, user_country, user_others, user_mobilenumber, user_gender, forgotten_answer) values('$email', '$pass', '$country', '$others','$mobilenumber', '$gender', '$forgotten_answer')";

	    $query = mysqli_query($con, $insert);

	    if($query){
	    	echo"<script>alert('Congratulation $name, your account has been created successfully')</script>";

	    	echo"<script>window.open('signin.php', '_self')</script>";
	    }
	    else{
	    	echo"<script>alert('Registration failed, try again!')</script>";
	    	echo"<script>window.open('signup.php', '_self')</script>";
	    }


	}

?>