<!DOCTYPE html>
<html>
<head>
    <title>Create New Account</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initail-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Courgette|Pacifico:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="cssibm/signup.css">
</head>
<body>
    <div class="signup-form">
        <form action="" method="post">
            <div class="form-header">
                <h2>Sign Up</h2>
                <p>Website to know about Food Security during COVID-19</p>
            </div>
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" class="form-control" name="user_email" placeholder="someone@site.com" autocomplete="off" required> 
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" name="user_pass" placeholder="Password" autocomplete="off" required> 
            </div>
            <div class="form-group">
                <label>Country</label>
                <select class="form-control" name="user_country" required>
                    <option disabled="">Select a Country</option>
                    <option>India</option>
                    <option>USA</option>
                    <option>Pakistan</option>
                    <option>UK</option>
                    <option>Bangladesh</option>
                    <option>France</option>
                    <option>Not above mentioned</option>
                </select> 
            </div>
            <div class="form-group">
                <label>Others</label>
                <input type="Others" class="form-control" name="user_others" placeholder="Other country please mention here.If not type:NA" autocomplete="off" required> 
            </div>
            <div class="form-group">
                <label>Mobile Number</label>
                <input type="mobile number" class="form-control" name="user_mobilenumber" placeholder="Mobile Number" autocomplete="off" required> 
            </div>
            <div class="form-group">
                <label>Gender</label>
                <select class="form-control" name="user_gender" required>
                    <option disabled="">Select gender</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Others</option>
                </select> 
            </div>
            <div class="form-group">
                <label>Forgotten Answer</label>
                <input type="text" class="form-control" name="forgotten_answer" placeholder="Favorite Person Name" autocomplete="off" required> 
            </div>
            <div class="form-group">
                <label class="checkbox-inline"><input type="checkbox" required>I accept the<a href="#"> terms and conditions </a> &amp;<a href="#"> privacy policy</a></label>
            </div>
 
            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block btn-log" name="sign_up">Sign up</button> 
            </div>
            <?php include("signup_user.php"); ?>        
        </form>a
        <div class="text-center small" style="color: #67428B;">Already have an account?<a href="signin.php">Signin Here</a></div>
        
    </div>
</body>
</html>