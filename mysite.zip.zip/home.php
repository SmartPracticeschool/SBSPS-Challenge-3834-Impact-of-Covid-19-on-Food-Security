<html>
<head>
<title>Food Security</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="cssibm/home.css">
</head>
<body>
<header>
<div>
	<ul class="nav-area">
		<li><a href="signin.php">Home</a></li>
		<li><a href="signup.php">About</a></li>
		<li><a href="forgot_pass.php">Services</a></li>
		<li><a href="contact.php">Contact</a></li>
	</ul>
</div>

<div class="Welcome-text">
	<h1><b><center>Welcome to our Website</center></b></h1>
	<h2><b><i><center>Food Security</center></i></b></h2>
</div>
<br>
<br>
<br>
<div class="Welcome1-text">
<ul>
	<li><b><h3>&nbsp1.Alarmed by a potential rise in food insecurity during the COVID-19 pandemic, many countries and organizations are mounting special efforts to keep agriculture safely running as an essential business.</h3></b></li><br>
	<li><b><h3>&nbsp2.Markets well supplied in affordable and nutritious food, and consumers still able to access and purchase food despite movement restrictions and income losses.</h3></b></li><br>
	<li><b><h3>&nbsp3.While the COVID-19 pandemic has had little impact on the global food supply chain so far, international organizations are warning about food security problems in the near future, as the ongoing health crisis ripples through the global food trade.</h3></b></li><br>
	<li><b><h3>&nbsp4.Low-income and trade-dependent countries are likely to be worst affected, but wealthy countries may well be hit by price spikes, and panic buying.</h3></b></li><br>
	<li><b><h3>&nbsp5.Locust attack in several places may created very big disaster in food and agriculture products and it give so many losses to the agriculture people.So the expenses of product is quite incresed.</h3></b></li><br>
	<li><b><h3>&nbsp6.To overcome that problems government of several countries taking necessary steps like...i)Maintaining Social distances.ii)Covering or Wearing face masks.iii)Allowing required amount of customers to shop.</h3></b></li><br>
	<li><b><h3>&nbsp7.Although several countries taking steps and some of people helping by denoting things and money.But still there is poverty of food in some countries.So help them and donate whatever we can....</h3></b></li><br>
	<li><b><h1><center>Stay safe! Stay healthy!</center></h1></b></li>

</ul>
</div>
<a href="contact.php">Contact Us</a>

</header>






<div class="right-header-details">
<form method="post">
<button name="logout" class="btn btn-danger">Logout</button>
</form>
<?php
if(isset($_POST['logout'])){
$update_msg = mysqli_query($con, "UPDATE userdetails SET log_in='Offline' WHERE user_email='$user_email'");
header("Location:logout.php");
exit();
}


?>
</div>
</body>
</html>