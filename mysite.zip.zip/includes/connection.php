<?php
$con = mysqli_connect("localhost", "root", "", "covid") or die("Connection was not established");
?>